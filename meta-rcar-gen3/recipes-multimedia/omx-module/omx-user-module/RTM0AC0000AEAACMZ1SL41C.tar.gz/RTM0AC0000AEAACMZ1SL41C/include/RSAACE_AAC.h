/*------------------------------------------------------------------------------*/
/* AAC Encode Middleware                                                        */
/* Copyright(C) 2009-2015 Renesas Electronics Corporation. All rights reserved. */
/*------------------------------------------------------------------------------*/

#ifndef _RSAACE_AAC_H_
#define _RSAACE_AAC_H_

/* return code */
typedef int RSAACE_TYPE_ERROR;
#define RSAACE_R_GOOD                           ((int)(   0)) /* normal */
#define RSAACE_C_CHECK                          ((int)(   1)) /* warning */
#define RSAACE_E_ERROR                          ((int)(  -1)) /* error */

/* status code */
#define RSAACE_R_NO_ERROR                       ((int)(   0)) /* normal */
#define RSAACE_C_END_OF_FILE                    ((int)( 100)) /* encoded the end of input pcm */
#define RSAACE_C_LACK_FRAME                     ((int)( 101)) /* detected lack of input pcm, encoded pcm added zero value to the input */
#define RSAACE_C_PRE_ENCODE                     ((int)( 102)) /* pre-process of encoding */
#define RSAACE_C_BEFORE_END_OF_FILE             ((int)( 103)) /* encoded before the end of input pcm */
#define RSAACE_E_CHANNEL_MODE                   ((int)(-100)) /* illegal channel mode */
#define RSAACE_E_SAMPLE_RATE                    ((int)(-101)) /* unsupported sample rate */
#define RSAACE_E_BIT_RATE                       ((int)(-102)) /* unsupported bit rate */
#define RSAACE_E_STREAM_FORMAT                  ((int)(-104)) /* illegal value */
#define RSAACE_E_ENABLE_CBR                     ((int)(-105)) /* illegal value */
#define RSAACE_E_HOME                           ((int)(-107)) /* illegal value */
#define RSAACE_E_ORIGINAL_COPY                  ((int)(-108)) /* illegal value */
#define RSAACE_E_COPY_ID_PRSNT                  ((int)(-112)) /* illegal value */
#define RSAACE_E_GAP                            ((int)(-114)) /* illegal value */
#define RSAACE_E_MODE                           ((int)(-115)) /* illegal value */
#define RSAACE_E_NULL                           ((int)(-116)) /* illegal alignment address */

/* encode parameters */
typedef struct _RSAACE_AACInfo
{
    unsigned int  channelMode;                         /* monaural:0, stereo:1, dual monaural:2 */
    unsigned int  sampleRate;                          /*  8000- 48000 */
    unsigned int  bitRate;                             /*  8000-288000, per chnnel */
    unsigned int  outputFormat;                        /* ADTS:0, ADIF:1(recommendation), RAW:2 */
    unsigned int  enable_cbr;                          /* vbr:0(recommendation), cbr:1 */
    unsigned int  gap;                                 /* 0(recommendation), 1 */
    unsigned int  mode;                                /* 0(recommendation), 1 */
    unsigned int  home;                                /* 0(recommendation), 1 */
    unsigned int  original_copy;                       /* 0(recommendation), 1 */
    unsigned int  copyright_id_present;                /* 0(recommendation), 1 */
    unsigned char copyright_id[9];                     /* 0(recommendation) */

} RSAACE_AACInfo;

/* work area */
#define WORKSIZE 14010
typedef struct _RSAACE_AAC
{
    int   AAC_status;     /* status code */
    int   AAC[WORKSIZE];  /* work buffer */

} RSAACE_AAC;

/* API Prototype */
extern RSAACE_TYPE_ERROR RSAACE_Init( RSAACE_AAC  *work, RSAACE_AACInfo *info );
extern RSAACE_TYPE_ERROR RSAACE_Encode( RSAACE_AAC *work, short *input, unsigned int *pcnt, unsigned char *output, unsigned int *bcnt );
extern unsigned int RSAACE_get_version( void );
#endif /* _RSAACE_AAC_H_ */

