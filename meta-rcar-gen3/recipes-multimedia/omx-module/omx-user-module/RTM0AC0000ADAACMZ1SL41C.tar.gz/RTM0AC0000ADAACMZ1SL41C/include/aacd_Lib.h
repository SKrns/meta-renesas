/*------------------------------------------------------------------------------*/
/* AAC Decode Middleware                                                        */
/* Copyright(C) 2012-2015 Renesas Electronics Corporation. All rights reserved. */
/*------------------------------------------------------------------------------*/

#ifndef AACD_LIB_H
#define AACD_LIB_H


/*--------------------------------------------------------------------------*/
/*	Define																	*/
/*--------------------------------------------------------------------------*/
#ifndef ACMW_COMM_STDTYPES_H
#define ACMW_COMM_STDTYPES_H

/*==========================================================================*/
/*	Define Type for Software IP												*/
/*==========================================================================*/
typedef signed char					ACMW_INT8;
typedef signed short				ACMW_INT16;
typedef signed int					ACMW_INT32;
typedef unsigned char				ACMW_UINT8;
typedef unsigned short				ACMW_UINT16;
typedef unsigned int				ACMW_UINT32;
typedef signed short				ACMW_BOOL;

#endif	/* ACMW_COMM_STDTYPES_H */


/*==========================================================================*/
/*	Define Error Code														*/
/*==========================================================================*/
#define	AACD_RESULT_OK				((ACMW_INT32)(0x00000000))
#define	AACD_RESULT_NG				((ACMW_INT32)(0x00000001))
#define	AACD_RESULT_WARNING			((ACMW_INT32)(0x00000002))
#define	AACD_RESULT_FATAL			((ACMW_INT32)(0x00000003))

/*==========================================================================*/
/*	Define Error Factor														*/
/*==========================================================================*/
#define	AACD_ERR_NONE				((ACMW_UINT32)(0x00000000u))
#define	AACD_ERR_POINTER			((ACMW_UINT32)(0x00000010u))
#define	AACD_ERR_PARAMETER			((ACMW_UINT32)(0x00000020u))
#define	AACD_ERR_SEQUENCE			((ACMW_UINT32)(0x00000040u))
#define	AACD_ERR_INPUT_DATA_SIZE	((ACMW_UINT32)(0x00000100u))
#define	AACD_ERR_STREAM				((ACMW_UINT32)(0x00001000u))
#define	AACD_ERR_HEADER				((ACMW_UINT32)(0x00010000u))
#define	AACD_ERR_CHANGED_FS			((ACMW_UINT32)(0x00020000u))
#define	AACD_ERR_CHANGED_CH			((ACMW_UINT32)(0x00040000u))
#define	AACD_ERR_PROGRAM_CONFIG		((ACMW_UINT32)(0x00080000u))
#define	AACD_ERR_1ST2ND_FRAME		((ACMW_UINT32)(0x00100000u))
#define	AACD_ERR_CRC				((ACMW_UINT32)(0x00200000u))
#define	AACD_ERR_DECODE				((ACMW_UINT32)(0x01000000u))

/*==========================================================================*/
/*	Standard Define 														*/
/*==========================================================================*/
#define AACD_DSE_NUM				(16)
#define AACD_ELE_NUM				(16)

/*==========================================================================*/
/*	Specification Define 													*/
/*==========================================================================*/

/*--------------------------------------------------------------------------*/

/*==========================================================================*/
/*	Other Define 															*/
/*==========================================================================*/

/*--------------------------------------------------------------------------*/
/*	HE-AAC File Structure													*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*	API Structure															*/
/*--------------------------------------------------------------------------*/
/*==========================================================================*/
/*	[9] Define Struct aacd_elementInfo										*/
/*==========================================================================*/
/* [Description]
 *   Structure that specifies processing condition
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_UINT32		nElement;
	ACMW_BOOL		aEleIsCpe[AACD_ELE_NUM];
	ACMW_UINT32		aEleTag[AACD_ELE_NUM];
} aacd_elementInfo;
/*--------------------------------------------------------------------------*/

/*==========================================================================*/
/*	[1] Define Struct aacd_getMemorySizeConfigInfo							*/
/*==========================================================================*/
/* [Description]
 *   Structure that specifies condition when size is acquired memory requirement
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_BOOL	bSbrDisableFlag;
	ACMW_BOOL	bPsDisableFlag;
	ACMW_BOOL	bDrcEnableFlag;
} aacd_getMemorySizeConfigInfo;

/*==========================================================================*/
/*	[2] Define Struct aacd_getMemorySizeStatusInfo							*/
/*==========================================================================*/
/* [Description]
 *   Structure that stores memory requirement and size calculation result
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_UINT32		nStaticSize;
	ACMW_UINT32		nScratchSize;
	ACMW_UINT32		nInputBufferSize;
	ACMW_UINT32		nOutputBufferSize;
	ACMW_UINT32		nStackSize;
} aacd_getMemorySizeStatusInfo;

/*==========================================================================*/
/*	[3] Define Struct aacd_workMemoryInfo									*/
/*==========================================================================*/
/* [Description]
 *   Structure that specifies address information on work memory
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	void*		pStatic;
	void*		pScratch;
} aacd_workMemoryInfo;

/*==========================================================================*/
/*	[4] Define Struct aacd_initConfigInfo									*/
/*==========================================================================*/
/* [Description]
 *   Structure that specifies decode condition when initializing it
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_BOOL		bSbrDisableFlag;
	ACMW_BOOL		bPsDisableFlag;
	ACMW_BOOL		bDownSampleSBRFlag;
	ACMW_BOOL		bDrcEnableFlag;
	ACMW_UINT16		nTargetRefLevel;
	ACMW_UINT16		nDefaultProgRefLevel;
	ACMW_UINT32		nCompress;
	ACMW_UINT32		nBoost;
	ACMW_BOOL		bOutputChMapType;
	ACMW_BOOL		bDisablePCEFlag;
	ACMW_BOOL		bOutBitsPerSample;
	ACMW_UINT16		nFormatType;
} aacd_initConfigInfo;

/*==========================================================================*/
/*	[5] Define Struct aacd_decConfigInfo									*/
/*==========================================================================*/
/* [Description]
 *   Structure that specifies processing condition
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_UINT32			nExtSamplingRate;
	ACMW_BOOL			bSetPceFlag;
	aacd_elementInfo	sFrontElement;
	aacd_elementInfo	sSideElement;
	aacd_elementInfo	sBackElement;
	aacd_elementInfo	sLfeElement;
} aacd_decConfigInfo;

/*==========================================================================*/
/*	[6] Define Struct aacd_decStatusInfo									*/
/*==========================================================================*/
/* [Description]
 *   Structure that stores decoder processing result
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_UINT32 nSamplingRate;
	ACMW_UINT32 nOutSamplingRate;
	ACMW_UINT16 nOutSamplesPerFrame;
	ACMW_UINT16 nChannelNum;
	ACMW_UINT16 nOutChannelNum;
	ACMW_UINT16 nChannelConfig;
	ACMW_UINT16 nOutChannelConfig;
	ACMW_BOOL	bDualChannelMode;
	ACMW_UINT16	nDualChannelTag;
	ACMW_BOOL	bCrcEnable;
	ACMW_BOOL	bSbrFound;
	ACMW_BOOL	bPsFound;
	ACMW_BOOL	bPceFound;
	ACMW_BOOL	bMpegDmxCoefPresent;
	ACMW_UINT16 nMpegDmxCoef;
	ACMW_BOOL	bPseudoSurroundEnable;
	ACMW_UINT16 nDseNum;
	ACMW_UINT16 aDseTag[AACD_DSE_NUM];
} aacd_decStatusInfo;

/*==========================================================================*/
/*	[7] Define Struct aacd_ioBufferConfigInfo								*/
/*==========================================================================*/
/* [Description]
 *   Structure that specifies parameter of input buffer
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_UINT8*		pInBuffStart;
	ACMW_UINT32		nInBuffOffsetBits;
	ACMW_UINT32		nInBuffSetDataSize;
	void**			pOutBuffStart;
	ACMW_UINT32		nOutBuffSize;
	ACMW_UINT8		nDseBuffNum;
	ACMW_UINT8**	pDseBuffStart;
	ACMW_UINT16		nDseBuffSize;
} aacd_ioBufferConfigInfo;

/*==========================================================================*/
/*	[8] Define Struct aacd_ioBufferStatusInfo								*/
/*==========================================================================*/
/* [Description]
 *   Structure that stores buffer memory information result after decode
 *
 * [Note]
 *   User allocate
 *==========================================================================*/
typedef struct {
	ACMW_UINT8*		pInBuffLast;
	ACMW_UINT32		nInBuffUsedDataSize;
	void**			pOutBuffLast;
	ACMW_UINT32		nOutBuffUsedDataSize;
	ACMW_UINT16		aDseDataSize[AACD_DSE_NUM];
} aacd_ioBufferStatusInfo;
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*	API Function Prototype													*/
/*--------------------------------------------------------------------------*/
extern ACMW_INT32 aacd_GetMemorySize( const aacd_getMemorySizeConfigInfo* const pGetMemorySizeConfigInfo,
									 aacd_getMemorySizeStatusInfo*		 const pGetMemorySizeStatusInfo );

extern ACMW_INT32 aacd_Init( const aacd_workMemoryInfo* const pWorkMemInfo,
							const aacd_initConfigInfo* const pInitConfigInfo );

extern ACMW_INT32 aacd_Decode( const aacd_workMemoryInfo*		const	pWorkMemInfo,
							const aacd_decConfigInfo*			const	pDecConfigInfo,
							const aacd_ioBufferConfigInfo*		const	pBuffConfigInfo,
							aacd_decStatusInfo*					const	pDecStatusInfo,
							aacd_ioBufferStatusInfo*			const	pBuffStatusInfo );

extern ACMW_UINT32 aacd_GetErrorFactor( const aacd_workMemoryInfo* const pWorkMemInfo );

extern ACMW_UINT32 aacd_GetVersion( void );
/*--------------------------------------------------------------------------*/

#endif	/* AACD_LIB_H */
/* End of File */
